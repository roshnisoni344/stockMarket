package com.cognizant.Application.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class StockExchange {
	
	@Id

	private long exchangeId;
	private String stockExchangeName;
	private String brief;
	private String  contactAdress;
	private String remarks;
	
	
	
	
	
	public long getExchangeId() {
		return exchangeId;
	}
	public void setExchangeId(long exchangeId) {
		this.exchangeId = exchangeId;
	}
	public String getStockExchangeName() {
		return stockExchangeName;
	}
	public void setStockExchangeName(String stockExchangeName) {
		this.stockExchangeName = stockExchangeName;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public String getContactAdress() {
		return contactAdress;
	}
	public void setContactAdress(String contactAdress) {
		this.contactAdress = contactAdress;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "StockExchange [exchangeId=" + exchangeId + ", stockExchangeName=" + stockExchangeName + ", brief="
				+ brief + ", contactAdress=" + contactAdress + ", remarks=" + remarks + "]";
	}
	

}






