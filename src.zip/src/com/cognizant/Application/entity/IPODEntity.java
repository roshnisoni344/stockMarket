package com.cognizant.Application.entity;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity 
public class IPODEntity {
	
	
	@Id
	
	private int ipodId;
	private String companyName;
	private String stockExchangeName;
	private double pricePerShare;
	private double numberOfShares;
	private Timestamp openDateTime;
	private String remark;
	
	
	public int getIpodId() {
		return ipodId;
	}
	public void setIpodId(int ipodId) {
		this.ipodId = ipodId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getStockExchangeName() {
		return stockExchangeName;
	}
	public void setStockExchangeName(String stockExchangeName) {
		this.stockExchangeName = stockExchangeName;
	}
	public double getPricePerShare() {
		return pricePerShare;
	}
	public void setPricePerShare(double pricePerShare) {
		this.pricePerShare = pricePerShare;
	}
	public double getNumberOfShares() {
		return numberOfShares;
	}
	public void setNumberOfShares(double numberOfShares) {
		this.numberOfShares = numberOfShares;
	}
	
	public Timestamp getOpenDateTime() {
		return openDateTime;
	}
	public void setOpenDateTime(Timestamp openDateTime) {
		this.openDateTime = openDateTime;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "IPODEntity [ipodId=" + ipodId + ", companyName=" + companyName + ", stockExchangeName="
				+ stockExchangeName + ", pricePerShare=" + pricePerShare + ", numberOfShares=" + numberOfShares
				+ ", openDateTime=" + openDateTime + ", remark=" + remark + "]";
	}
	

}


