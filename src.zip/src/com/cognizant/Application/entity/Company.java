package com.cognizant.Application.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Company implements Serializable  {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8375974526221704614L;
	@Id
	private long companyId;
	private String companyName;
	private double turnOver;
	private String CEO;
	private String boardOfDirectors;
	private String listedInStockExchange;
	private String sectorName;
	private String briefWriteUp;
	
	
	public long getStockCodeInEachStock() {
		return companyId;
	}
	public void setStockCodeInEachStock(long companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public double getTurnOver() {
		return turnOver;
	}
	public void setTurnOver(double turnOver) {
		this.turnOver = turnOver;
	}
	public String getCEO() {
		return CEO;
	}
	public void setCEO(String cEO) {
		CEO = cEO;
	}
	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}
	public String getListedInStockExchange() {
		return listedInStockExchange;
	}
	public void setListedInStockExchange(String listedInStockExchange) {
		this.listedInStockExchange = listedInStockExchange;
	}
	public String getSector() {
		return sectorName;
	}
	public void setSector(String sector) {
		this.sectorName = sector;
	}
	public String getBriefWriteUp() {
		return briefWriteUp;
	}
	public void setBriefWriteUp(String briefWriteUp) {
		this.briefWriteUp = briefWriteUp;
	}
	@Override
	public String toString() {
		return "Company [stockCodeInEachStock=" + companyId + ", companyName=" + companyName + ", turnOver="
				+ turnOver + ", CEO=" + CEO + ", boardOfDirectors=" + boardOfDirectors + ", listedInStockExchange="
				+ listedInStockExchange + ", sector=" + sectorName + ", briefWriteUp=" + briefWriteUp + "]";
	}
	

}



