package com.cognizant.Application;

import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

import com.cognizant.Application.config.AuthorizationClass;

@SpringBootApplication
public class SpringBootJwtApplication {

	@Bean
	public FilterRegistrationBean jwtFilter() {
		final FilterRegistrationBean registrationBean = new FilterRegistrationBean();
		registrationBean.setFilter(new AuthorizationClass());
		registrationBean.addUrlPatterns("/authenticate/*");

		return registrationBean;
	}

	public static void main(String[] args)
	{
     
		SpringApplication app = new SpringApplication(SpringBootJwtApplication.class);
		app.setDefaultProperties(Collections.singletonMap("server.port", "8086"));
		app.run(args);		
	}
}