package com.cognizant.Application.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/authenticate")
public class AuthorizationController {


	@RequestMapping("/user/users")
	public String loginSuccess() {
		
		if(UserController.set==0){
		return "Login Successful!   User  \n  You are Authenticated";
		}else{
			UserController.set=0;
			return "  Admin ";
		}
	}

}
