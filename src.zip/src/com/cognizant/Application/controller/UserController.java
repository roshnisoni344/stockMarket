package com.cognizant.Application.controller;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.Application.entity.Company;
import com.cognizant.Application.entity.User;
import com.cognizant.Application.service.CompanyService;
import com.cognizant.Application.service.UserService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@CrossOrigin(origins = "http://localhost", maxAge = 3600)
@RestController
@RequestMapping("/client")
public class UserController {

	@Autowired
	private UserService userService;
    @Autowired
    private CompanyService companyservice;
	public static int set = 0;

	@RequestMapping(value = "/registeration", method = RequestMethod.POST)
	public User registerUser(@RequestBody User user) {
		System.out.println(user.getUserName());
		return userService.save(user);
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)

	   public User updateUser(@RequestBody User user) {

	      return userService.save(user);

	   }

	@RequestMapping(value = "/signin", method = RequestMethod.POST)
	public String signin(@RequestBody User signin) throws ServletException {

		String jwtToken = "";

		if (signin.getUserName() == null || signin.getPassword() == null) {
			throw new ServletException("Please fill in username and password");
		}

		String userName = signin.getUserName();
		String password = signin.getPassword();

		User user = userService.findUser(userName, password);

		if (user == null) {
			throw new ServletException("User email not found.");
		}

		String pwd = user.getPassword();

		if (!password.equals(pwd)) {
			throw new ServletException("Invalid login. Please check your name and password.");
		}

        if(user.getUserType().equalsIgnoreCase("Admin")){
        		set=1;
	
        	}else {
        		set=0;
        	}
		
		jwtToken = Jwts.builder().setSubject(userName).claim("roles", "user").setIssuedAt(new Date())
				.signWith(SignatureAlgorithm.HS256, "secretkey").compact();

		return jwtToken;
	}

	

	@RequestMapping(value = "/searchCompany", method = RequestMethod.POST)

	   public Company SearchCompany(@RequestBody Company company) {
          String companyName=company.getCompanyName();
	      return companyservice.findByCompanyName(companyName);

	   }

	

	
}
