/**
 * 
 */
package com.cognizant.Application.controller;

import java.util.Date;

import javax.servlet.ServletException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.Application.entity.Company;
import com.cognizant.Application.entity.StockExchange;
import com.cognizant.Application.entity.User;
import com.cognizant.Application.service.CompanyService;
import com.cognizant.Application.service.StockExchangeService;
import com.cognizant.Application.service.UserService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * @author 770067
 *
 */
@CrossOrigin(origins = "http://localhost", maxAge = 3600)
@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired

    CompanyService companyservice;
	@Autowired
	
	UserService userservice;
	@Autowired
	
	StockExchangeService stockexchangeservice;
	
	@RequestMapping(value = "/addCompany", method = RequestMethod.POST)
	public Company registerCompany(@RequestBody Company company) {
		System.out.println(company.getCompanyName());
		return companyservice.save(company);
	}
	
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)

	   public User updateUser(@RequestBody User user) {

	      return userservice.save(user);

	   }
	
	
	@RequestMapping(value = "/signin", method = RequestMethod.POST)
	public String signin(@RequestBody User signin) throws ServletException {

		String jwtToken = "";

		if (signin.getUserName() == null || signin.getPassword() == null) {
			throw new ServletException("Please fill in username and password");
		}

		String userName = signin.getUserName();
		String password = signin.getPassword();

		User user = userservice.findUser(userName, password);
		if (user == null) {
			throw new ServletException("User email not found.");
		}

		
		String pwd = user.getPassword();
		String uType=user.getUserType();

	

		if (!password.equals(pwd)) {
			throw new ServletException("Invalid login. Please check your name and password.");
		}

        if(uType.equalsIgnoreCase("Admin")){
        	//	UserController.set=1;
         	
    		jwtToken = Jwts.builder().setSubject(userName).claim("roles", "user")
    				.signWith(SignatureAlgorithm.HS256, "secretkey").compact();
 UserController.set=1;   		
	
        	}else {
        		throw new ServletException("invalid");
        	}
	
        return jwtToken;
		
	}

	
	@RequestMapping(value = "/deleteCompany", method = RequestMethod.POST)
	public String deletecompany(@RequestParam long companyId) {
		
	 companyservice.deleteByCompanyId(companyId);
	 
	 return "Record Deleted";
	}
	
	@RequestMapping(value = "/deleteStockExchange", method = RequestMethod.POST)
	public String deleteStock(@RequestParam long exchangeId) {
		
	 stockexchangeservice.deleteByExchangeId(exchangeId);
	 
	 return "Stock Deleted";
	}
	
	
	@RequestMapping(value = "/addStockExchange", method = RequestMethod.POST)
	public StockExchange registerCompany(@RequestBody StockExchange stockexchange) {
		System.out.println(stockexchange.getStockExchangeName());
		return stockexchangeservice.save(stockexchange);
	}
	
	
	
}
