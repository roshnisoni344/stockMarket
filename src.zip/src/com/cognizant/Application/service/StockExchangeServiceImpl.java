package com.cognizant.Application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.Application.dao.StockExchangeDao;
import com.cognizant.Application.entity.StockExchange;

@Service
public class StockExchangeServiceImpl implements StockExchangeService {

	@Autowired
	private StockExchangeDao stockexchangedao;
	@Override
	public void deleteByExchangeId(long exchangeId) {
		// TODO Auto-generated method stub
		stockexchangedao.delete(exchangeId);
	}

	@Override
	public StockExchange save(StockExchange stockexchange) {
		// TODO Auto-generated method stub
		return stockexchangedao.save(stockexchange);
	}

}
