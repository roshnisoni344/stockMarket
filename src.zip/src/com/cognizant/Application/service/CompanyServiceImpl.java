package com.cognizant.Application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.Application.dao.CompanyDao;
import com.cognizant.Application.entity.Company;
@Service
public class CompanyServiceImpl implements CompanyService {
@Autowired
private CompanyDao companydao;
	@Override
	public Company save(Company company) {
	
		return companydao.save(company);
	}

	@Override
	public Company findByCompanyName(String companyName) {
		
		return companydao.findByCompanyName(companyName);
	}




	@Override
	public void deleteByCompanyId(long companyId) {
		// TODO Auto-generated method stub
		companydao.delete(companyId);
	}

}
