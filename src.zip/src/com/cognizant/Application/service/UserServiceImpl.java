package com.cognizant.Application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.Application.dao.UserDao;
import com.cognizant.Application.entity.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	public User save(User user) {
		return userDao.save(user);
	}

	@Override
	public User findUser(String userName, String password) {
		
		
		
		
		return userDao.findDistinctByUserNameAndPassword(userName, password);
	}

	@Override
	public User findByUserName(String userName) {
		
		return userDao.findByUserName(userName);
	}

	

}
