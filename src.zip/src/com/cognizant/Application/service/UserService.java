package com.cognizant.Application.service;

import com.cognizant.Application.entity.User;

public interface UserService {
	User save(User user);

User findUser(String userName, String password);

	User findByUserName(String userName);
	
	
}
