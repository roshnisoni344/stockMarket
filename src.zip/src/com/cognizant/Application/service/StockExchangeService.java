package com.cognizant.Application.service;

import com.cognizant.Application.entity.StockExchange;

public interface StockExchangeService {
	void deleteByExchangeId(long exchangeId);
	  StockExchange save(StockExchange stockexchange);
	  
}
