package com.cognizant.Application.service;



import com.cognizant.Application.entity.Company;


public interface CompanyService {
	     Company save(Company company);
		Company findByCompanyName(String companyName);
		void deleteByCompanyId(long companyId);
}