package com.cognizant.Application.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.Application.entity.User;

@Repository
public interface UserDao extends CrudRepository<User, Long> {

	User findDistinctByUserNameAndPassword(String userName, String password);

	User findByUserName(String userName);
}
