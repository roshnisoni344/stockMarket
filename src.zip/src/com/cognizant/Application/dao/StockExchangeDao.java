package com.cognizant.Application.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.Application.entity.StockExchange;

@Repository
public interface StockExchangeDao extends CrudRepository<StockExchange, Long> {

	void deleteByExchangeId(long exchangeId);
}
