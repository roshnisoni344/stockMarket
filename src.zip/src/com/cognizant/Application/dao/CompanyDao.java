package com.cognizant.Application.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.Application.entity.Company;




@Repository
public interface CompanyDao extends CrudRepository<Company, Long> {

	Company findByCompanyName(String companyName); 
  void deleteByCompanyId(long companyId);

}
