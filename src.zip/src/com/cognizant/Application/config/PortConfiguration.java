package com.cognizant.Application.config;

import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;

public class PortConfiguration implements EmbeddedServletContainerCustomizer {

	@Override
	public void customize(ConfigurableEmbeddedServletContainer portConfiguration) {
		// TODO Auto-generated method stub
		portConfiguration.setPort(8086);
	}

}
